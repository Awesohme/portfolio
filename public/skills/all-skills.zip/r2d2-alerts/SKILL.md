---
name: R2D2Alerts
description: Toggle an R2D2 beep that plays whenever Claude Code needs permission or asks a question. Installs the hooks + bundled sound if off, removes them if on. Re-run to flip.
metadata:
  short-description: Toggle R2D2 beep on permission/question prompts
---

# R2D2Alerts

Plays a short R2D2 beep through the macOS `afplay` whenever Claude Code raises a
**permission prompt** or a **notification** (i.e. it's waiting on you). This is a
toggle: invoking it turns the alerts ON if they're off, and OFF if they're on —
the same pattern as MuteReadouts/UnmuteReadouts.

**Platform:** macOS only (`afplay`). On Linux swap `afplay` for `paplay`/`aplay`;
on Windows use PowerShell's `[System.Media.SoundPlayer]`.

## What it controls

Two hooks in `~/.claude/settings.json`, both running the same command async:

- **`PermissionRequest`** — fires on *every* permission prompt, regardless of which
  window has focus. This is the reliable one.
- **`Notification`** — fires when Claude is waiting on input. macOS/iTerm only raises
  this when the terminal is NOT focused (same trigger as the terminal bell), so it
  covers the "I'm in another app" case.

The sound lives at `~/.claude/sounds/r2d2.mp3`. No sound is bundled: save a short sound of your own at
`assets/r2d2.mp3` in this skill folder before the first run.

## How to run it

Determine current state, then flip it. "Installed" = a `PermissionRequest` hook whose
command contains `r2d2.mp3` exists in `~/.claude/settings.json`.

### Step 1 — detect current state

```bash
jq -e '.hooks.PermissionRequest // [] | map(.hooks[]?.command) | flatten | any(test("r2d2.mp3"))' \
  ~/.claude/settings.json >/dev/null 2>&1 && echo "ON" || echo "OFF"
```

### Step 2a — if OFF, turn it ON

1. Ensure the sound exists, restoring from the bundled copy if missing:

   ```bash
   mkdir -p ~/.claude/sounds
   [ -s ~/.claude/sounds/r2d2.mp3 ] || cp "$CLAUDE_SKILL_DIR/assets/r2d2.mp3" ~/.claude/sounds/r2d2.mp3
   ```

   (If `$CLAUDE_SKILL_DIR` isn't set, use the absolute path to this skill's
   `assets/r2d2.mp3`.)

2. Merge the two hooks into `~/.claude/settings.json` **without clobbering existing
   hooks** — read the file, add the `PermissionRequest` and `Notification` keys (or
   append to their arrays if they already exist), write it back. The hook object for
   each:

   ```json
   {
     "matcher": "",
     "hooks": [
       { "type": "command", "command": "afplay ~/.claude/sounds/r2d2.mp3", "async": true }
     ]
   }
   ```

   Use an absolute path in the actual command (`afplay /Users/<you>/.claude/sounds/r2d2.mp3`)
   — hook commands don't reliably tilde-expand.

3. Validate: `jq -e '.hooks.PermissionRequest' ~/.claude/settings.json` must exit 0.

4. Reply: *"R2D2 alerts ON 🔵 — you'll hear a beep on every permission prompt and when
   I'm waiting on you. Open `/hooks` once (or restart) to load the config. Re-run
   /R2D2Alerts to turn it off."*

### Step 2b — if ON, turn it OFF

1. Read `~/.claude/settings.json`, remove the `r2d2.mp3` command entries from the
   `PermissionRequest` and `Notification` hook arrays. If an array becomes empty,
   drop the whole event key. **Leave all non-r2d2 hooks untouched.**
2. Validate the JSON still parses (`jq -e . ~/.claude/settings.json`).
3. Leave the sound file in place (cheap, reusable on next toggle).
4. Reply: *"R2D2 alerts OFF. Re-run /R2D2Alerts to turn them back on."*

## Rules

- **Never replace the `hooks` object** — merge/prune only the r2d2 entries.
- **Always validate JSON with `jq -e`** after writing; a broken settings.json silently
  disables ALL settings.
- The settings watcher only picks up the change live if `~/.claude/` was being watched
  at session start — otherwise tell the user to open `/hooks` or restart.
