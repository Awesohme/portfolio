---
description: Toggle an R2D2 beep that plays whenever the AI coding agent needs permission or asks a question. Toggle on/off. (LLM-agnostic backup of the R2D2Alerts skill.)
---

# R2D2Alerts (portable / LLM-agnostic backup)

This is the backup, agent-agnostic copy of the `R2D2Alerts` skill. The live version
lives at `~/.claude/skills/r2d2-alerts/SKILL.md` (Claude Code). This copy exists so any
LLM coding tool (Codex, Cursor, Aider, GPT, Gemini) can re-create the behaviour from
plain instructions.

## What it does

Plays a short R2D2 beep whenever the coding agent **needs permission** or **is waiting
on the user**. It's a toggle: run it once to turn ON, run again to turn OFF.

No sound is bundled: save any short sound you like as `r2d2.mp3` next to this file.
Copy it to wherever the agent expects sounds (for Claude Code: `~/.claude/sounds/r2d2.mp3`).

## Claude Code implementation (the canonical one)

Claude Code triggers sounds via **hooks** in `~/.claude/settings.json`. Two events:

- `PermissionRequest` — every permission prompt, regardless of window focus.
- `Notification` — when the agent is waiting on input (focus-dependent on macOS/iTerm).

Hook object for each event (merge into `.hooks`, don't replace existing hooks):

```json
{
  "matcher": "",
  "hooks": [
    { "type": "command", "command": "afplay /ABS/PATH/.claude/sounds/r2d2.mp3", "async": true }
  ]
}
```

**Toggle logic:**
- Detect ON = a `PermissionRequest` hook command containing `r2d2.mp3` exists.
- OFF→ON: ensure the sound file is in place (copy your `r2d2.mp3` if missing),
  add both hook keys, validate with `jq -e .`.
- ON→OFF: remove only the `r2d2.mp3` entries from both arrays (drop a key if its array
  empties), validate JSON, leave the sound file in place.

## Playing the sound on other platforms

| OS | Command |
|----|---------|
| macOS | `afplay r2d2.mp3` |
| Linux | `paplay r2d2.mp3` or `aplay r2d2.mp3` (or `ffplay -nodisp -autoexit r2d2.mp3`) |
| Windows | `powershell -c "(New-Object Media.SoundPlayer 'r2d2.wav').PlaySync()"` (needs WAV) |

## Implementation for non-Claude agents

Most other agents don't have a permission-hook system. Closest equivalents:
- **Cursor / Aider / Codex:** no native permission-event hook — wire the sound to a
  terminal-bell handler or a wrapper script that watches for the agent's "awaiting
  input" state, then runs the platform play command above.
- **Generic approach:** if the tool emits a terminal bell (`\a`) on prompts, configure
  the terminal emulator to run `afplay r2d2.mp3` on bell.

## Rules (apply to any implementation)
- Never clobber existing config — merge/prune only the r2d2 entries.
- Always validate the config file parses after editing.
- Keep the play call async/non-blocking so it never delays the prompt.
