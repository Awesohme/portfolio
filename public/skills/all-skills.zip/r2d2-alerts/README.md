# R2D2 Alerts

Plays a beep whenever your AI coding agent needs your permission or is waiting on you. Bring your own sound.

Works with: Claude Code · other agents

## Install

**Claude Code:** copy this folder to `~/.claude/skills/r2d2-alerts/` (so the file sits at `~/.claude/skills/r2d2-alerts/SKILL.md`), then start a new session. Claude picks it up when it's relevant, or you can call it by name.

**Other AI agents (Codex, Cursor, Aider, Gemini and others):** open the `.md` file and paste it into your agent as instructions, or save it wherever your tool keeps its rules or custom commands. Each file is written in plain steps, so any capable coding agent can follow it.

## Before you start

No sound file is included. Save any short sound you like as `assets/r2d2.mp3` inside the skill folder before the first run.

## Licence

Free to use, change and share. A link back is appreciated but not required.

Made by Olamide Irojah · https://www.olamide-irojah.com.ng/skills
