---
description: Generate PRD, README, HTML + PowerPoint user guides, and a LinkedIn post, then auto-push docs to GitHub and print the live URL.
---

# /generate-project-docs

Generate four project documents — PRD, README, HTML user guide, PowerPoint user guide, and a LinkedIn post — then auto-push the user guide and README to GitHub (if a remote exists) and print the live URL.

All output goes into a `docs/` folder at the project root.

---

## Step 0 — Gather context

Do ALL of the following before writing anything:

1. Read any existing `README.md` or `CLAUDE.md` in the project root
2. Read `package.json` (or equivalent manifest) for the project name, stack, and scripts
3. Scan the `src/` or `app/` folder structure to understand features, pages, and roles
4. Run `git remote get-url origin 2>/dev/null` to capture the GitHub remote URL
5. Ask the user only what the code cannot tell you:
   - Product name and tagline
   - Target users and their roles (what each can do)
   - Is it live? If so, what is the live URL?
   - PM / author name for the PRD byline
   - What problem existed before this product?
   - LinkedIn author name and title for the post

Do not proceed until you have answers to all of the above.

Derive the GitHub username and repo name from the remote URL (e.g. `https://github.com/USER/REPO.git` → `USER` and `REPO`). Store these — they are used in the deploy step.

---

## Step 1 — PRD (`docs/PRD.md`)

Write a product requirements document in Markdown.

```markdown
# Product Requirements Document — {Product Name}

**Version:** 1.0
**Date:** {Month Year}
**Product Manager:** {name}
**Status:** {Draft | Beta | Live}

---

## 1. Overview
2–3 paragraph narrative — what it is, who it's for, why it exists.

## 2. Problem Statement
What was the situation before? What broke or cost time?
- Bullet list of specific pain points

## 3. Goals
| Goal | Metric |
|------|--------|
| ... | ... |

## 4. User Roles & Permissions
For each role:
| Role | Can do | Cannot do |

## 5. Core Features
### {Feature Name}
- What it does
- User story: "As a {role}, I can {action} so that {outcome}"
- Key UI behaviour / constraints

## 6. Non-Goals (v1)
- Explicit out-of-scope items

## 7. Tech Stack
| Layer | Technology |
|-------|-----------|

## 8. Success Criteria
- Conditions that mean the product shipped successfully

## 9. Open Questions
- Unresolved decisions or dependencies
```

---

## Step 2 — README (`docs/README.md`)

Developer-facing README.

```markdown
# {Product Name}

{One-sentence description}

**Live app:** {url}
**GitHub:** {repo url}

---

## What it does
2–3 sentence summary, then a role list.

## Tech stack
- Framework, DB, hosting, key libs

## Local development

### Prerequisites
Node version, env vars needed.

### Setup
```bash
git clone ...
cd ...
npm install
cp .env.example .env.local
npm run dev
```

### Environment variables
| Variable | Required | Description |

## Project structure
```
src/
  components/
  pages/
  hooks/
  services/
```

## Deployment
How it deploys (e.g. auto-deploy on push to main via Vercel).

## Contributing
Branch/PR conventions if applicable.
```

---

## Step 3 — HTML User Guide (`docs/user-guide.html`)

A single standalone HTML file. All styles in a `<style>` block — no external CSS frameworks. Use this design system:

**Design tokens:**
- Font: `'Poppins', sans-serif` (Google Fonts import)
- `--primary`: brand colour (default `#FF914D` unless a colour is identifiable from the code)
- `--bg`: `#f9f8f6`, `--card`: `#ffffff`, `--text`: `#1a1a2e`, `--muted`: `#5a5a7a`, `--border`: `#ede8e0`
- Cards: `border-radius: 12px`, max-width `860px` centred, `box-shadow: 0 2px 8px rgba(0,0,0,0.06)`
- Role badges coloured per role (admin = amber, preparer = purple, support = green or equivalent)

**Required sections:**
1. Header — product name, tagline, "User Guide" label, version badge
2. Table of contents — anchor links
3. Getting Started — install (if PWA), first login, roles explained
4. One section per user role — feature walkthroughs with numbered steps
5. Admin / power-user section — management flows
6. Notifications / integrations if applicable
7. Exporting / data export if applicable
8. FAQ — minimum 5 Q&A pairs
9. Footer — version, date, support contact

**Callout patterns:**
```html
<div class="callout tip"><strong>Tip:</strong> …</div>
<div class="callout warning"><strong>Note:</strong> …</div>
<ol class="steps"><li><span class="step-num">1</span><span>Do the thing</span></li></ol>
```

Make the guide detailed enough that a non-technical user can complete any task without asking for help. Do not summarise — explain every step.

---

## Step 4 — PowerPoint User Guide (`docs/user-guide-generator.py`)

Write a Python script that generates `docs/user-guide.pptx` using `python-pptx`. Then run it.

**Design system (match the HTML guide):**
```python
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

PRIMARY      = RGBColor(0xFF, 0x91, 0x4D)  # or brand colour
PRIMARY_DARK = RGBColor(0xE5, 0x82, 0x2D)
WHITE        = RGBColor(0xFF, 0xFF, 0xFF)
DARK         = RGBColor(0x1a, 0x1a, 0x2e)
MUTED        = RGBColor(0x6b, 0x72, 0x80)
LIGHT_BG     = RGBColor(0xFF, 0xF0, 0xE6)
BORDER       = RGBColor(0xe5, 0xe7, 0xeb)
```

**Slide types to implement (use helper functions):**

- `slide_cover(prs)` — full-bleed colour background, centred white card with product name + version
- `slide_section(prs, num, title, subtitle)` — orange left-bar accent, large section number watermark
- `slide_content(prs, title, bullets, icon, note)` — orange top bar + left strip, light header bar, bullet list. Support `##` prefix for sub-headings and `--` for indented items
- `slide_roles(prs, roles)` — three-column card layout, one card per role with coloured header
- `slide_table(prs, title, icon, headers, rows)` — alternating row colours, green tick / grey dash for permission cells

**Slide order:**

1. Cover
2. Section: Getting Started
3. Content: Signing in & account creation (or equivalent)
4. Section: Roles & Access
5. Roles card slide
6. Section: Core Feature 1 (repeat per major feature group)
7. Content slides for each feature (2–3 bullets max per slide, don't cram)
8. Section: Notifications / integrations if applicable
9. Section: Installing / setup if applicable
10. Section: FAQ
11. Content: FAQ answers

**Run the script:**

```bash
cd docs && python3 user-guide-generator.py
```

If `python-pptx` is not installed, run `pip3 install python-pptx` first, then retry.

---

## Step 5 — LinkedIn Post (`docs/linkedin-post.html`)

Standalone HTML. Same Poppins font and design tokens as the user guide.

**Layout:**

```text
page label: "LinkedIn / Blog Post — Copy & Share"

post-card:
  profile row: avatar (circle, initials), name + title, "• 1st", timestamp
  post body:
    hook (bold first sentence — grab attention)
    2–3 paragraph story: problem → build → outcome
    bullet list: 3–5 key features or wins
    closing CTA line
    hashtags (8–10, styled in brand colour)
  engagement bar: Like  •  Comment  •  Repost  •  Send
```

**Tone:** Personal, first-person, genuine builder voice. Ready to copy-paste into LinkedIn.

---

## Step 6 — Auto-deploy to GitHub

After all files are generated:

### 6a — Push README to repo root

```bash
cp docs/README.md README.md
git add README.md
git commit -m "docs: update README"
git push
```

### 6b — Push user guide HTML to repo root

```bash
cp docs/user-guide.html user-guide.html
git add user-guide.html
git commit -m "docs: add user guide HTML"
git push
```

If git push fails due to auth, remind the user to set a PAT or use their credential helper. Do not force-push.

### 6c — Output live URL

After a successful push, print:

```text
User guide live at:
  https://raw.githack.com/{GITHUB_USER}/{GITHUB_REPO}/main/user-guide.html

GitHub:
  https://github.com/{GITHUB_USER}/{GITHUB_REPO}/blob/main/user-guide.html
```

If there is no GitHub remote, skip 6a–6b and print:

```text
No GitHub remote detected. To deploy manually:
  1. Push user-guide.html to your repo root
  2. Access via: https://raw.githack.com/{user}/{repo}/main/user-guide.html
```

---

## Step 7 — Final summary

Print exactly this (filled in):

```text
Generated:
  docs/PRD.md
  docs/README.md
  docs/user-guide.html
  docs/user-guide.pptx
  docs/linkedin-post.html

Deployed:
  README.md → repo root (committed + pushed)
  user-guide.html → repo root (committed + pushed)
  Live: https://raw.githack.com/{USER}/{REPO}/main/user-guide.html

Next steps:
  • Review any [PLACEHOLDER] values in the docs
  • Share the live URL with your team
  • Copy the LinkedIn post from docs/linkedin-post.html and paste into LinkedIn
```

Do not create any other files. Do not modify any existing source code files.
