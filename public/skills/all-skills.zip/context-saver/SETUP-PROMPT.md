# ContextSaver — Universal Setup Prompt

Paste this prompt into any coding agent (Claude Code, Codex CLI, Cursor, Aider, etc.) to install the ContextSaver system on a new machine or for a new agent.

The system never loses session context between LLM runs. It generates a `.sessions/` folder per project with searchable Markdown summaries of every session, so any future LLM session can pick up where the last one left off.

**Scope:** ContextSaver only persists per-session history. It does NOT generate handoff documents, PR descriptions, or release notes — those are separate concerns owned by other skills (e.g. a dedicated `project-handoff-generator` skill).

---

## What you (the user) need before starting

- **Node.js 18+** installed
- The **`claude` CLI installed and already authenticated** (i.e. you can run `claude` interactively and it works) — summarisation shells out to `claude -p`, riding on that same login. No separate Anthropic API key is needed, which also avoids org-account API billing issues.
- A repo / project directory

---

## Prompt to paste into the agent

> Build a global session context persistence system called **ContextSaver** for my coding projects. The goal: never lose context between LLM sessions again.
>
> **Scope rule:** ContextSaver only writes `.sessions/` and `.sessions/INDEX.md`. It must NEVER write a `HANDOFF.md` file or any other root-level handoff doc — handoff is owned by a separate skill.
>
> **Reference implementation:** a complete, working copy of the hook is bundled alongside this doc at `context-saver/assets/session-start.js`. The fastest reliable path is to **copy that file verbatim** to `<config-dir>/hooks/session-start.js` rather than re-deriving it from the prose below — the prose explains *why* it works so you can adapt it per platform, but the bundled script is the source of truth. (`<config-dir>` = the value of `CLAUDE_CONFIG_DIR`, defaulting to `~/.claude`.)
>
> **Files to create:**
>
> 1. `~/.claude/hooks/session-start.js` — Node.js script that runs on `SessionStart` and `PreCompact` hooks (copy from `context-saver/assets/session-start.js`). It:
>    - Resolves the agent's config/state dir from the `CLAUDE_CONFIG_DIR` env var, falling back to `~/.claude`. Transcripts live under `<config-dir>/projects/`. (Do NOT hardcode `~/.claude` — when the user runs with a custom config dir, the default `~/.claude` is stale and the real transcripts are elsewhere; hardcoding it makes the hook silently save nothing.)
>    - Finds the transcript to summarise by **matching the project, not by reconstructing a directory name.** The sanitized `<config-dir>/projects/<sanitized-path>/` dir is only a fast first guess; the authoritative method scans every project dir for the most-recent transcript whose recorded working directory (`cwd`) equals the current project root. (The `cwd` field is NOT on the transcript's first line — that's a summary record — it appears on the message lines, so scan the first ~20 lines for the first one carrying `cwd`.) This is essential because a session launched from a parent workspace dir gets filed under the parent's dir, so a dir-name lookup finds nothing. A `--manual` run keeps a project-scoped match and only falls back to the globally-newest transcript (with a warning) when nothing matches by `cwd`; automatic runs never grab another project's session.
>    - Skips if that session ID is already in `INDEX.md`
>    - Extracts the transcript by sampling the **start and end** of the session — first ~40 + last ~60 text messages, with a `[middle of session omitted]` marker between (short sessions kept whole). This is deliberate: a first-N-only window dropped the back half of long sessions, so the summary missed work completed/pushed/renamed late. The summariser is also told the END reflects the final state and to prefer it when start and end disagree.
>    - Summarises by shelling out to the `claude` CLI itself — `claude -p --output-format text --model claude-haiku-4-5-20251001`, prompt piped via stdin, run with `spawnSync`. This reuses whatever session already authenticates the CLI, so **no API key, no SDK install, and no billing setup are needed**. The CLI binary path is resolved once via `command -v claude` (override with a `CLAUDE_BIN` env var if it's not on PATH). If the CLI call fails (missing binary, non-zero exit, empty output) the function returns `null` and the hook skips that summarisation cleanly instead of throwing.
>    - Writes the summary to `<project_root>/.sessions/YYYY-MM-DD_<slug>.md`
>    - Appends a row to `<project_root>/.sessions/INDEX.md`
>    - Exits silently if the cwd is not a real project (no `.git` and no `package.json`)
>
> 2. `~/.claude/skills/context-saver/SKILL.md` — a slash command skill `/context-saver` (skill name `ContextSaver`) that runs the same summarisation on demand mid-session, before context compacts or before closing a long chat. The skill body just invokes `node ~/.claude/hooks/session-start.js`.
>
>    **IMPORTANT structure rule:** Claude Code skills must live as `<skill-name>/SKILL.md` (a directory containing a `SKILL.md` file). A flat `.md` file at `~/.claude/skills/context-saver.md` will NOT be discovered.
>
> 3. Update `~/.claude/settings.json` — register `SessionStart` and `PreCompact` hooks pointing to `node /Users/<username>/.claude/hooks/session-start.js` with `async: true`.
>
> **Per-project setup (one-time, per repo):**
> - Add `.sessions/` to `.gitignore`
>
> **Session file format** (`.sessions/YYYY-MM-DD_<slug>.md`):
> ```
> # Session: <title>
> Date / Branch / Session ID
>
> ## What Was Done
>
> ## Files Changed
>
> ## Key Decisions & Patterns
>
> ## Backend / Handoff Notes
>
> ## Pending Tasks
>
> ## Errors Hit & Fixes
> ```
>
> Note: the "Backend / Handoff Notes" heading is just a **section inside the session file** — not a root-level `HANDOFF.md`. Do not output a root-level handoff doc.
>
> **INDEX.md format:**
> ```
> | Date | Summary | Branch | Files Changed |
> ```
>
> **Design constraints:**
> - LLM-agnostic: session files are plain Markdown, greppable with no special tooling
> - Any LLM can be told: "Read `.sessions/INDEX.md` then the relevant session file before starting work"
> - Node.js only, **zero external dependencies** — summarisation shells out to the already-authenticated `claude` CLI instead of calling the Anthropic SDK/API directly, so there is nothing to `npm install` and no API key to provision.
> - **Porting to a different agent's CLI** (Codex, Cursor, Aider, etc.): replace the `runClaudePrompt()` call with that agent's own non-interactive "print"/one-shot completion command, run under its own authenticated session, passing the prompt the same way (stdin or arg) and parsing stdout the same way. The rest of the script (transcript discovery, `.sessions/` writing, INDEX.md format) is agent-agnostic and can be copied as-is.
>
> Build all files. Test that the hook fires on session start and produces a correctly named, correctly formatted session file.

---

## How to use across agents

After installation, **before starting any work in a coding agent**, paste:

> Before you do anything, read `.sessions/INDEX.md` in this repo. Then read the most recent 1–2 session files relevant to what I'm about to ask. Use that context to inform your work.

That single instruction makes Codex, Cursor, Aider, Copilot Workspace, or any LLM session-aware — they read the Markdown history before acting.

---

## Files on this machine

- Hook: `~/.claude/hooks/session-start.js`
- Skill: `~/.claude/skills/context-saver/SKILL.md` (name: `ContextSaver`)
- Hook registration: `~/.claude/settings.json` (`hooks.SessionStart` + `hooks.PreCompact`)
- No API key or SDK install required — summarisation runs through the already-authenticated `claude` CLI.

---

## Per-project `.gitignore` entry

```
.sessions/
```

(No `HANDOFF.md` line — that file is owned by a different skill if you use one.)
