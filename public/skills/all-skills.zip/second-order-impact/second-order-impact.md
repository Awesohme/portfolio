---
description: Analyse a new feature and surface every second-order engineering impact the team may have missed (full-stack TS/NestJS + Next.js).
---

# /second-order-impact

Analyse a new feature and surface every second-order engineering impact the team may have missed. Works for any full-stack TypeScript/NestJS + Next.js project that uses permission slugs, per-client modules and event-driven notifications. Adjust the paths below to your own codebase.

---

## How to invoke

```
/second-order-impact <feature description>
```

Example: `/second-order-impact Leave management with requests and approvals`

---

## Step 1 — Scan the codebase for existing patterns

Before generating the checklist, read the following to understand what already exists:

1. **Sidebar module slugs** — the file that defines your sidebar (e.g. `src/lib/sidebar.ts`): read every `module:` field to see existing slug naming conventions
2. **Permission slugs** — same file, read every `permissions:` array entry
3. **Notification types** — your notifications service: read the `NotificationType` enum
4. **Client notification type IDs** — look for `ClientNotificationTypes` enum in the backend or frontend services
5. **Existing email templates** — list files in your email templates folder to understand naming conventions
6. **Existing notification sagas** — list files in your notification sagas or handlers folder
7. **Audit log action patterns** — read your audit log module to understand how actions are named

If any of these paths don't exist, skip them and note it.

---

## Step 2 — Generate the second-order impact checklist

Output a structured report with the following sections. For each item, be specific — use the naming conventions found in Step 1.

---

### 🔌 Backend API Endpoints

List every HTTP endpoint needed. Format:
```
METHOD /path — description (who calls it, auth required)
```

Flag if any endpoint needs role-based data scoping (e.g. employees see own records, approvers see all).

---

### 🔑 Permission Slugs

List new permission slugs to register in the backend.

For each slug:
- Slug name (follow existing conventions, e.g. `leave-requests`, `leave-balances`)
- Which roles get which actions: `canCreate`, `canView`, `canUpdate`, `canDelete`
- Flag if a separate "view-all" slug is needed for privileged roles

Also flag: **which existing roles** need these permissions assigned in your admin backoffice.

---

### 📦 Module Slug (Backoffice)

The slug to register in your admin backoffice so it can toggle this feature per client.

Follow the `manage-{domain}` convention (e.g. `manage-leave`).

Note: the frontend sidebar entry must set `module: 'manage-{domain}'` and `hasModuleAccess` must pass `isSuperAdmin` to bypass the check for super admins.

---

### 📧 Email Templates

List every email template needed. Format:

```
File: {domain}.{event}.email.template.ts
Function: {domainEvent}EmailTemplate(recipientName, ...fields, link, client: ClientFooterBranding)
Trigger: [what action fires this]
Recipients: [resolved by permission slug + action, NOT by role name]
  → To requester: user who created the record
  → To approvers: users in roles where canUpdate on '{slug}' = true
Key fields in details card: [list them]
```

Recipient resolution must always be slug-based — never hardcode role names.

---

### 🔔 Notification Sagas + Commands

List the event → saga → command → handler chain for each notification.

Format:
```
DomainEvent (e.g. LeaveRequestSubmittedEvent)
  → saga: {domain}-notification.saga.ts
  → command: {DomainEvent}NotificationCommand
  → handler: resolves recipients via permission slug query, sends email + in-app
```

Create one saga file per domain (not one per event).

---

### ⚙️ Notification Config Entries

List the new `NotificationType` enum values and `ClientNotificationTypes` IDs to add.

Suggest tiers:
- **TIER_1 (Critical):** Actions that require immediate response (cannot be disabled)
- **TIER_2 (Time-Sensitive):** Actions requiring response within hours
- **TIER_3 (Informational):** Status updates, no action required

The notification settings UI picks these up automatically once the backend returns them.

---

### 📋 Audit Log Events

List every state change that should emit an audit log entry.

For each:
- `action` string (e.g. `LEAVE_REQUEST_SUBMITTED`)
- Actor: who performed it
- Data snapshot: what fields to capture

---

### 🗂️ File/Attachment Storage

Flag any upload points in the feature (forms, modals, etc.) and note:
- Which endpoint accepts the file
- Storage bucket/path convention (follow existing patterns)
- Whether file references are stored on the domain entity or as a separate attachment entity

---

### 🔗 Frontend Service Hooks

List the SWR hooks to create when backend is ready. Follow the existing `useApi` pattern.

Format:
```
useLeaveRequests(params) → GET /leave-requests
useLeaveRequest(id) → GET /leave-requests/:id
useCreateLeaveRequest() → POST /leave-requests
useUpdateLeaveRequestStatus(id) → PATCH /leave-requests/:id/{action}
```

Also note where mock data + local state in the frontend page needs to be replaced.

---

### 👥 Role & Permission Assignment

Flag any onboarding/setup actions needed in your admin backoffice after the backend is deployed:

- Which roles need which new permission slugs (and at what access level)
- Whether new user invites should get any of these permissions by default
- Any default role setup in the seed data

---

### 📊 Analytics / Aggregate Endpoints

Flag if the feature has KPI cards or summary stats on the UI. For each:
- What the card shows
- Whether it can be derived from a paginated list endpoint or needs a dedicated `/summary` or `/analytics` endpoint

---

### 🔀 Related Domains

Flag any sub-features that are distinct backend domains (separate tables, services, controllers) even if they appear as one feature on the frontend.

Example: leave balances and accrual rules are a separate domain from leave requests, even though both live under "Leave" in the sidebar.

---

## Step 3 — Output a backend handoff summary

End the report with a short prioritised list of what to build first, e.g.:

```
Priority order for backend:
1. Domain entities + migrations
2. API endpoints (basic CRUD + status transitions)
3. Permission slugs + module slug registration in the admin backoffice
4. Role assignments for existing roles
5. Notification sagas + email templates
6. Audit logging
7. File storage endpoints
8. Analytics/aggregate endpoints
```

---

## Notes

- Always use permission slugs (not role names) to resolve notification recipients
- Never suggest hardcoding role names like "Finance" or "Admin" — the client may name them anything
- Flag anything that needs the backend lead's approval before frontend can wire up real API calls
- If the feature already has a frontend mock implementation, note which files will need to swap mock data for real hooks
