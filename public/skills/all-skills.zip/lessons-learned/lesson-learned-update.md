---
description: Scan THIS project's session transcripts for lessons learned (bugs, errors, gotchas), then fold them into the global skill files. PII-redacted and locked to the current project.
---

# /lesson-learned-update

You are reviewing recent session transcripts from this project to extract new lessons learned, then updating the global skill files so future projects benefit from them.

---

## Step 1 — Find this project's transcripts

**Hard rule: only ever read transcripts for the CURRENT project.** Never scan another
project's folder — other projects may contain PII (emails, phone numbers, data about
minors) or credentials that will trip the safety filter and block the session when read
back into the conversation. Derive the folder from the live working directory; do not
eyeball the list and guess.

Claude Code stores transcripts at `~/.claude/projects/<sanitized-cwd>/*.jsonl`.
The sanitized CWD replaces `/` with `-` and drops the leading slash.
For example: `/Users/you/projects/my-app` → `-Users-you-projects-my-app`

Compute the folder from `pwd` and bind it to a variable so every later command is
scoped to it. Abort if the folder doesn't exist — do not fall back to another folder:
```bash
PROJ_DIR="$HOME/.claude/projects/$(pwd | sed 's#^/##; s#/#-#g')"
echo "Scanning: $PROJ_DIR"
[ -d "$PROJ_DIR" ] || { echo "No transcript dir for this project — aborting."; exit 1; }
```

List this project's transcript files sorted by most recent:
```bash
ls -t "$PROJ_DIR"/*.jsonl 2>/dev/null | head -10
```

Also include subagent files:
```bash
ls -t "$PROJ_DIR"/subagents/*.jsonl 2>/dev/null | head -20
```

---

## Step 2 — Extract lessons from transcripts

Read the 5 most recent transcript files. For each file, scan for:

1. **Bugs that took more than one message to fix** — what was the root cause? What pattern caused it?
2. **Errors the user reported** — what was the user-facing message? What was the actual cause?
3. **Things Claude got wrong first and had to correct** — what assumption was wrong?
4. **Patterns that worked well** — what approach saved time or avoided a problem?
5. **Manual steps the user had to take** — things that could have been caught in code or scaffolding
6. **react-doctor or linter findings** — any category of issues that appeared
7. **Security gaps found** — missing auth checks, exposed keys, missing RLS policies
8. **Configuration surprises** — env vars, deployment settings, third-party service quirks

**Safety rule for this step:** never echo raw transcript content back into the
conversation. Transcripts can contain PII (emails, phone numbers, data about minors)
and credential-like strings; dumping them inline trips the safety classifier and blocks
the whole session. The extractor below **redacts** those before printing and caps both
per-message and total output so nothing bulk-floods the context.

```bash
python3 - <<'PYEOF'
import json, re

PATH = 'PATH_TO_JSONL'

# Redact anything PII- or secret-shaped before it can re-enter the conversation.
def redact(t):
    t = re.sub(r'[\w.+-]+@[\w-]+\.[\w.-]+', '[EMAIL]', t)
    t = re.sub(r'\+?\d[\d\s().-]{7,}\d', '[PHONE]', t)
    t = re.sub(r'(?i)\b(api[_-]?key|secret|token|password|passwd|bearer|private[_-]?key)\b[\s:=]*\S+',
               r'\1=[REDACTED]', t)
    t = re.sub(r'\b[A-Za-z0-9_\-]{32,}\b', '[REDACTED]', t)  # long opaque strings (keys/hashes)
    return t

printed = 0
LIMIT = 120  # max messages echoed; keeps the dump small and reviewable
with open(PATH) as f:
    for line in f:
        if printed >= LIMIT:
            print("... [truncated — review the rest in-file if needed] ...")
            break
        try:
            obj = json.loads(line)
            msg = obj.get('message', obj)
            role = msg.get('role', '')
            tag = {'user': 'USER', 'assistant': 'CLAUDE'}.get(role)
            if not tag:
                continue
            for c in msg.get('content', []):
                if isinstance(c, dict) and c.get('type') == 'text':
                    text = redact(c['text'])[:200]
                    if text.strip():
                        print(f"{tag}: {text}\n")
                        printed += 1
        except Exception:
            pass
PYEOF
```

If a transcript still looks PII-heavy after redaction, summarise it instead of printing
it — extract the *lessons* (Step 3 buckets) without quoting the raw content.

---

## Step 3 — Categorise findings

Group what you found into these buckets:

### A. New security patterns
Things not already in `/new-project-setup` that would prevent a bug.

### B. New audit checks
Things not already in `/project-audit` that would catch a problem.

### C. Refinements to existing content
Places where the existing skill gave incomplete or misleading guidance.

### D. Stack-specific lessons
Patterns specific to a library, service, or framework used in this project (e.g. Supabase, Next.js 15, Google Drive API, specific shadcn components).

### E. Process lessons
Things about how to work — what to check before pushing, what to verify manually, what the LLM tends to miss.

---

## Step 4 — Propose updates

Present a summary to the user:

```
## Lessons found in this project's sessions

### Would add to /new-project-setup:
- [lesson]: [why it matters]
- ...

### Would add to /project-audit:
- [check]: [what it catches]
- ...

### Would refine in existing skills:
- [section]: [current wording] → [better wording]
- ...

### Stack-specific (worth a separate skill?):
- [pattern]: [explanation]
- ...
```

Ask: "Should I apply all of these, or go through them one by one?"

---

## Step 5 — Apply approved updates

For each approved lesson:

1. Open the relevant global skill file:
   - `~/.claude/commands/new-project-setup.md`
   - `~/.claude/commands/project-audit.md`

   **If the target file does not exist, create it before adding the lesson.** Don't skip
   the lesson or error out. Scaffold a new skill file with YAML frontmatter and a clear
   structure, then add the lesson into it. Use this template:

   ```markdown
   ---
   description: <one line, present tense, describing what the skill does — shows in the / menu>
   ---

   # /<skill-name>

   <One paragraph: what this skill is for and when to run it.>

   ---

   ## Steps

   1. <first step>
   2. <...>
   ```

   Match the voice and format of the existing skills (concise, actionable, code examples
   where the pattern is non-obvious). After creating it, tell the user a new skill file
   was scaffolded and what it covers.

2. Find the right section to add it. If it doesn't fit an existing section, add a new one.

3. Write the update in the same voice and format as the rest of the file — concise, actionable, with code examples where the pattern is non-obvious.

4. If a lesson is stack-specific enough to warrant its own skill (e.g. a Supabase-specific checklist, a Google Drive integration guide), create a new file at `~/.claude/commands/<stack-name>-patterns.md`.

---

## Step 6 — Back up (optional)

If you keep a backup copy of your skill files somewhere else (a synced or Git folder, for example), copy the updated files there too:

```bash
cp ~/.claude/commands/new-project-setup.md <your-backup-folder>/
cp ~/.claude/commands/project-audit.md <your-backup-folder>/
# If a new skill was created:
cp ~/.claude/commands/<new-skill>.md <your-backup-folder>/
```

---

## Step 7 — Report

Tell the user:
- How many sessions were scanned
- How many lessons were extracted
- What was added to each skill file
- Where the files now live
- Suggest running `/project-audit` on the current project to verify the new checks catch what was found
