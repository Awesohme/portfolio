# Lessons Learned

Reads a project's past AI sessions for bugs and gotchas, then folds the lessons into your setup and audit checklists.

Works with: Claude Code

## Install

**Claude Code:** copy the `.md` command file into `~/.claude/commands/`, then type `/` plus its file name (without `.md`) in a new session.

**Other AI agents (Codex, Cursor, Aider, Gemini and others):** open the `.md` file and paste it into your agent as instructions, or save it wherever your tool keeps its rules or custom commands. Each file is written in plain steps, so any capable coding agent can follow it.

## Before you start

Reads Claude Code session files, so it needs Claude Code.

## Licence

Free to use, change and share. A link back is appreciated but not required.

Made by Olamide Irojah · https://www.olamide-irojah.com.ng/skills
