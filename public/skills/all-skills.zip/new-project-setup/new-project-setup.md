---
description: Scaffold a new Next.js + Supabase project from scratch with security and React best practices baked in (targets 95+/100 react-doctor, zero day-one gaps).
---

# /new-project-setup

You are setting up a new Next.js + Supabase project from scratch. Apply every pattern in this document before writing any business logic. The goal is a clean foundation that scores 95+/100 on react-doctor and has zero security gaps from day one.

Ask the user for the project name, stack details, and Supabase usage before starting. Then execute the steps below in order.

---

## Step 0 — Confirm stack

Ask the user:
1. Project name and directory
2. Are they using Supabase? (Auth + DB, DB only, or neither)
3. React version (default to 19)
4. Tailwind version (default to v3.4+)
5. Are they using Next.js App Router? (assume yes)

---

## Step 1 — Environment variables

Create `.env.local` and `.env.example`. Never put secrets in NEXT_PUBLIC_ variables.

```
# .env.example

# ── Supabase (client-safe) ────────────────────────────────
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=

# ── Supabase (server-only — NEVER prefix with NEXT_PUBLIC_) ──
SUPABASE_SERVICE_ROLE_KEY=   # service_role key, not the anon key

# ── App ───────────────────────────────────────────────────
NEXT_PUBLIC_APP_URL=
```

**Rules to communicate to the user:**
- `SUPABASE_SERVICE_ROLE_KEY` bypasses all Row Level Security. It must ONLY be read server-side (Server Actions, Route Handlers, server components). Never import it in client components.
- The anon key and service_role key both look like long `eyJ...` JWTs — they are NOT interchangeable.
- In Supabase dashboard: Project Settings → API → copy the **service_role** key (not the anon/public key).

---

## Step 2 — Supabase client files

Create these three files. They handle server components, route handlers, and the admin client respectively.

**`src/lib/supabase/server.ts`**
```ts
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export async function createClient() {
  const cookieStore = await cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() { return cookieStore.getAll(); },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {}
        },
      },
    }
  );
}
```

**`src/lib/supabase/route.ts`** (for Route Handlers)
```ts
import { createServerClient } from "@supabase/ssr";
import type { CookieOptions } from "@supabase/ssr";
import type { NextRequest, NextResponse } from "next/server";

type CookieToSet = { name: string; value: string; options: CookieOptions };

export function createRouteClient(request: NextRequest) {
  const pendingCookies: CookieToSet[] = [];
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() { return request.cookies.getAll(); },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value, options }) => {
            request.cookies.set(name, value);
            pendingCookies.push({ name, value, options });
          });
        },
      },
    }
  );
  return {
    supabase,
    applyCookies(response: NextResponse) {
      pendingCookies.forEach(({ name, value, options }) =>
        response.cookies.set(name, value, options)
      );
      return response;
    },
  };
}
```

**`src/lib/supabase/admin.ts`** (service-role client — server-only)
```ts
import { createClient } from "@supabase/supabase-js";

export class MissingServiceRoleError extends Error {
  constructor() {
    super("SUPABASE_SERVICE_ROLE_KEY is not set. Add it to Vercel environment variables (use the service_role key, not the anon key) and redeploy.");
    this.name = "MissingServiceRoleError";
  }
}

export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new MissingServiceRoleError();
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
```

---

## Step 3 — Auth helpers

**`src/lib/auth.ts`**
```ts
import { cache } from "react";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export type CurrentUser = { id: string; email: string | null };

export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  return { id: user.id, email: user.email ?? null };
});

export async function requireUser(): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/auth/login?error=session");
  return user;
}
```

---

## Step 4 — Server action template

Every `"use server"` file must follow this pattern. The auth check is ALWAYS the first line of every exported action — before validation, before database access, before anything.

```ts
"use server";

import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

export async function exampleAction(formData: FormData) {
  // ✅ Auth check FIRST — always
  await requireUser();

  // Then validation
  const name = String(formData.get("name") ?? "").trim();
  if (!name) return { ok: false, error: "Name is required." };

  // Then database
  const supabase = await createClient();
  const { error } = await supabase.from("items").insert({ name });
  if (error) return { ok: false, error: error.message };

  revalidatePath("/");
  return { ok: true };
}
```

**Hard rule:** If a server action file does not have `await requireUser()` or `await requireAdmin()` as the first statement in every exported function, it is a security hole. React Doctor will flag these as "Server auth actions" errors.

---

## Step 4b — Admin user-management pattern (invite + password + invite message)

If the app has an admin who creates other users, use this pattern. It creates an **active account immediately** (no email round-trip), generates a strong password, and produces a ready-to-send invite message the admin copies once. Battle-tested in production.

**Server action** — admin-guarded, uses the Supabase **service-role** admin client (never the anon client):

```ts
"use server";

import { requireAdmin, type AppRole } from "@/lib/auth";
import { createAdminClient, MissingServiceRoleError } from "@/lib/supabase/admin";

export async function inviteUserAction(formData: FormData) {
  await requireAdmin();                       // ✅ admin check FIRST

  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const username = String(formData.get("username") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const role = String(formData.get("role") ?? "viewer") as AppRole;

  if (password.length < 8) return { ok: false, error: "Password must be at least 8 characters." };

  let admin;
  try { admin = createAdminClient(); }
  catch (err) {
    if (err instanceof MissingServiceRoleError)
      return { ok: false, error: "Server can't reach Supabase admin — check SUPABASE_SERVICE_ROLE_KEY (service_role, not anon) and redeploy." };
    throw err;
  }

  // Create the auth user with email_confirm so they can log in straight away
  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email, password, email_confirm: true, user_metadata: { username },
  });
  if (createError || !created?.user) return { ok: false, error: createError?.message ?? "Could not create user." };

  // Mirror into profiles; roll back the auth user if the profile write fails
  const { error: upsertError } = await admin.from("profiles").upsert(
    { id: created.user.id, email, username, role, is_active: true },
    { onConflict: "id" },
  );
  if (upsertError) {
    await admin.auth.admin.deleteUser(created.user.id);  // ✅ no orphaned auth users
    return { ok: false, error: upsertError.message };
  }

  return { ok: true, user: { id: created.user.id, email, username, role } };
}

// Reset uses updateUserById on the same admin client — never resetPasswordForEmail here
export async function resetUserPasswordAction(userId: string, newPassword: string) {
  await requireAdmin();
  if (newPassword.length < 8) return { ok: false, error: "Password must be at least 8 characters." };
  const admin = createAdminClient();
  const { error } = await admin.auth.admin.updateUserById(userId, { password: newPassword });
  return error ? { ok: false, error: error.message } : { ok: true };
}
```

**Client — crypto-strong password generator** (no ambiguous chars like 0/O/1/l):

```ts
function randomPassword(length = 14): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%";
  const c = typeof window !== "undefined" && window.crypto ? window.crypto : undefined;
  if (c) {
    const buf = new Uint32Array(length);
    c.getRandomValues(buf);                              // ✅ crypto RNG, not Math.random
    return Array.from(buf, (n) => chars[n % chars.length]).join("");
  }
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}
```

**Client — "Shuffle" button + copy-once invite message.** Seed the password field with `randomPassword()`, give it a Shuffle button (`onClick={() => setPassword(randomPassword())}`), and after a successful invite build a copyable message via `navigator.clipboard.writeText(...)`:

```ts
const message = [
  `Hi! You have been added to <App Name> as a ${roleLabel}.`,
  "", "Please see your credentials below:",
  `Username: ${username}`, `Email: ${email}`, `Password: ${password}`,
  "", "You can log in here:", window.location.origin,
].join("\n");
```

**Hard rules for this pattern:**
- Admin-only Supabase operations (`auth.admin.*`) require the **service-role key**, used **only in `"use server"` files** — never expose it to the client, never `NEXT_PUBLIC_` it.
- Always **roll back** the created auth user if the profile insert fails (no orphaned auth records).
- The password is **shown once** — tell the admin to copy the invite before dismissing; afterwards they can only reset it.
- Guard destructive/role actions against locking out the **last active admin** (block demote/deactivate/delete when the target is the last one).

---

## Step 5 — Supabase RLS bootstrap SQL

Run this in Supabase SQL Editor after creating your tables. **Enabling RLS without adding policies locks everyone out silently — no error, just empty results and blocked inserts.**

```sql
-- 1. Enable RLS on every table (run once per table)
alter table public.your_table enable row level security;

-- 2. Create a role helper function (security definer = bypasses RLS itself)
create or replace function public.current_app_role()
returns text
language sql
security definer
set search_path = public
stable
as $$
  select role from public.profiles
  where id = auth.uid() and is_active = true
  limit 1
$$;

revoke all on function public.current_app_role() from public;
grant execute on function public.current_app_role() to authenticated;

-- 3. Read policy — authenticated users with a profile can read
create policy "your_table_read"
on public.your_table
for select to authenticated
using (public.current_app_role() is not null);

-- 4. Write policy — only ops roles can write
create policy "your_table_insert"
on public.your_table
for insert to authenticated
with check (public.current_app_role() in ('admin', 'programme_officer'));

create policy "your_table_update"
on public.your_table
for update to authenticated
using (public.current_app_role() in ('admin', 'programme_officer'))
with check (public.current_app_role() in ('admin', 'programme_officer'));

-- 5. Always add a delete policy too — omitting it blocks deletes silently
create policy "your_table_delete"
on public.your_table
for delete to authenticated
using (public.current_app_role() = 'admin');
```

**Checklist before going to production:**
- [ ] Every table has RLS enabled
- [ ] Every table has at least a SELECT policy
- [ ] Every table has INSERT, UPDATE, DELETE policies if the app writes to it
- [ ] The `current_app_role()` function exists and is granted to `authenticated`

**Applying migrations / DDL programmatically (when you can't use the SQL Editor UI):**
The service-role key over PostgREST (`/rest/v1/...`) can read/write rows but **cannot run DDL**. For migrations connect to Postgres directly. The direct host `db.<ref>.supabase.co:5432` often won't resolve on some networks; the reliable path is the **session pooler**: `postgresql://postgres.<ref>:<db-password>@aws-0-<region>.pooler.supabase.com:5432/postgres`. The **region matters** — wrong region rejects auth, so probe `aws-0-{us-east-1,us-east-2,eu-west-1,eu-central-1,...}` until one connects. Needs `psycopg2` (install in a venv; macOS system pip is PEP-668 locked). Data reads/writes still go fastest over PostgREST + service key.

---

## Step 6 — Error boundary

Create `src/app/(protected)/error.tsx` (and one for any other route segment that can fail):

```tsx
"use client";

import { useEffect } from "react";
import { Button } from "@/components/ui/button";

export default function ProtectedError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => { console.error(error); }, [error]);
  const isDev = process.env.NODE_ENV === "development";

  return (
    <main className="flex min-h-[60vh] items-center justify-center p-8">
      <div className="max-w-lg space-y-3">
        <h1 className="text-lg font-medium">Something went wrong.</h1>
        <p className="text-sm text-muted-foreground">
          {isDev ? error.message : "An unexpected error occurred. Try again or contact an admin."}
        </p>
        {isDev && error.stack ? (
          <pre className="max-h-64 overflow-auto rounded-md border bg-muted/40 p-3 text-xs">
            {error.stack}
          </pre>
        ) : null}
        <div className="flex gap-2">
          <Button onClick={reset}>Try again</Button>
          <Button variant="outline" onClick={() => window.location.reload()}>Reload</Button>
        </div>
      </div>
    </main>
  );
}
```

Without this, any unhandled render error becomes a white screen with "Application error: a client-side exception has occurred."

---

## Step 7 — React 19 + Tailwind patterns

Enforce these from day one so react-doctor never flags them:

**forwardRef is dead in React 19.** Pass `ref` as a regular prop:
```tsx
// ❌ Old (React 18)
const Input = forwardRef<HTMLInputElement, Props>((props, ref) => <input ref={ref} {...props} />);

// ✅ New (React 19)
function Input({ ref, ...props }: Props & { ref?: React.Ref<HTMLInputElement> }) {
  return <input ref={ref} {...props} />;
}
```

**Tailwind v3.4+ size shorthand:**
```tsx
// ❌ Verbose
<div className="w-4 h-4" />
<div className="h-6 w-6" />

// ✅ Shorthand
<div className="size-4" />
<div className="size-6" />
```

**Parallel awaits:**
```ts
// ❌ Sequential (slow)
const user = await getUser();
const profile = await getProfile();

// ✅ Parallel (fast)
const [user, profile] = await Promise.all([getUser(), getProfile()]);
```

**Hoist Intl constructors** — never create them inside functions:
```ts
// ❌ Creates new object on every call
function format(date: Date) {
  return new Intl.DateTimeFormat("en-NG").format(date);
}

// ✅ Created once at module scope
const dateFormatter = new Intl.DateTimeFormat("en-NG");
function format(date: Date) {
  return dateFormatter.format(date);
}
```

**flatMap over map+filter:**
```ts
// ❌ Two passes
items.map(transform).filter(Boolean)

// ✅ One pass
items.flatMap(item => condition ? [transform(item)] : [])
```

**Accessible inputs by default** — make the shared `Input`/`Textarea` fall back to the placeholder as `aria-label`, so placeholder-only fields are never unlabelled (fixes a whole class of `control-has-associated-label` at the source):
```tsx
export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  const ariaLabel = props["aria-label"] ?? (typeof props.placeholder === "string" ? props.placeholder : undefined);
  return <input aria-label={ariaLabel} className={cn("app-input", className)} {...props} />;
}
```
Also: never wrap a **custom** control (a `SelectMenu`/`Button` that renders a `<button>`/`<div>`) in `<label>` — it associates with nothing. Use a `<div>` for the visible text and `aria-label` on the control. Give icon-only buttons an `aria-label` and an explicit `type`.

**No em-dashes in UI copy** — react-doctor flags `—` in JSX text. Use `:` / `.` / `;` in user-facing strings. (An em-dash as an empty-value placeholder, `{value || "—"}`, is fine.)

**Reduced-motion** — add this to `globals.css` so motion-sensitive users get a calm UI:
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

**Never call `redirect()` / `notFound()` inside a try/catch** in a server action — they throw a Next control signal the catch will swallow, silently breaking navigation. Capture the target in a variable inside the try and redirect *after* it.

---

## Step 8 — Run react-doctor before first commit

```bash
npx react-doctor@latest
```

Target: **90+ / 100** before you push anything to production. Fix all "Server auth actions" errors immediately — they are security holes. Fix forwardRef and size shorthand mechanically. Performance issues (Promise.all, flatMap, Intl) fix as you encounter them.

---

## Step 9 — .claude/settings.json

Create this in the project root to reduce permission prompts during development:

```json
{
  "permissions": {
    "allow": [
      "Bash(npm run lint *)",
      "Bash(npm run build *)"
    ]
  }
}
```

---

## Final checklist before going live

- [ ] All server actions call `requireUser()` or `requireAdmin()` as line 1
- [ ] `SUPABASE_SERVICE_ROLE_KEY` is set on Vercel (not the anon key)
- [ ] Every Supabase table has RLS enabled AND policies for SELECT, INSERT, UPDATE, DELETE
- [ ] `error.tsx` exists for every protected route segment
- [ ] No `forwardRef` in React 19 components
- [ ] react-doctor score ≥ 90
- [ ] `.env.example` is committed, `.env.local` is gitignored
- [ ] No secrets in any `NEXT_PUBLIC_` variable
