# Skills by Olamide Irojah

- **ContextSaver** (`context-saver/`): Saves a short summary of every AI coding session into your project, so the next session, or another AI tool, picks up where you left off.
- **ContextCatchup** (`context-catchup/`): Reads those saved summaries at the start of a session and tells you what is still pending before you touch anything.
- **Project Audit** (`project-audit/`): Checks a Next.js + Supabase app for security, performance and React gaps, then gives a score and a fix list by severity.
- **New Project Setup** (`new-project-setup/`): Starts a new Next.js + Supabase app with sign-in, database security and error handling done properly from day one.
- **Project Docs Generator** (`project-docs/`): Writes a PRD, a README, HTML and PowerPoint user guides and a LinkedIn post from your codebase.
- **Second-Order Impact** (`second-order-impact/`): Lists everything else a new feature will need, from permissions and emails to notifications and audit logs, before the team finds out late.
- **Lessons Learned** (`lessons-learned/`): Reads a project's past AI sessions for bugs and gotchas, then folds the lessons into your setup and audit checklists.
- **Handoff Generator** (`handoff-generator/`): Writes a complete handoff document so another person, chat or AI tool can carry on the work without losing context.
- **R2D2 Alerts** (`r2d2-alerts/`): Plays a beep whenever your AI coding agent needs your permission or is waiting on you. Bring your own sound.
- **Effort Routing** (`effort-routing/`): A simple way to choose how hard the AI should think, and which model to use, so you get quality without paying for it everywhere.

Each folder has its own README with install steps.

Free to use, change and share. https://www.olamide-irojah.com.ng/skills
