# Handoff Generator

Writes a complete handoff document so another person, chat or AI tool can carry on the work without losing context.

Works with: Any AI agent

## Install

**Claude Code:** copy this folder to `~/.claude/skills/handoff-generator/` (so the file sits at `~/.claude/skills/handoff-generator/SKILL.md`), then start a new session. Claude picks it up when it's relevant, or you can call it by name.

**Other AI agents (Codex, Cursor, Aider, Gemini and others):** open the `.md` file and paste it into your agent as instructions, or save it wherever your tool keeps its rules or custom commands. Each file is written in plain steps, so any capable coding agent can follow it.

## Licence

Free to use, change and share. A link back is appreciated but not required.

Made by Olamide Irojah · https://www.olamide-irojah.com.ng/skills
