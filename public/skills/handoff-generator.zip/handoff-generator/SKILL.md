---
name: project-handoff-generator
description: Use when the user wants a complete handoff document for moving work to a new chat, another LLM, another engineer, or another project. The skill always requires an output path and produces a self-contained Markdown handoff file with enough context for someone else to continue.
metadata:
  short-description: Create full project handoff docs
---

# Project Handoff Generator

Use this skill to produce a portable Markdown handoff that another LLM, engineer, or future chat can use to continue work without losing context.

## Required Input

Use the output location from the user's invocation when one is provided. Do not ask for confirmation just because a destination was included in the same request.

If the user gives a folder, create a Markdown file inside it.

If the user gives a full `.md` path, write exactly there.

If the user gives an ambiguous location, ask one concise clarifying question before writing.

If the user does not provide a path or location, ask one concise question:

> Where should I output the handoff `.md` file?

Do not proceed to file creation without an output path.

## Workflow

1. Identify the project root, repo URL, current branch, and local status.
2. Gather only targeted context:
   - app/product purpose
   - tech stack
   - roles/personas
   - key features
   - important architecture decisions
   - recent changes
   - known bugs, risks, and pending tasks
   - important commands
   - deployment details
   - secrets that were used, described without exposing values
3. Write a single self-contained Markdown handoff.
4. Include exact file paths and commands where useful.
5. Include copyable SQL/code blocks if database fixes are part of the context.
6. Avoid unnecessary narrative; make it practical for continuation.

## Handoff Structure

Use this structure unless the user requests something else:

```md
# [Project Name] Handoff

## Project
- Name:
- Repo:
- Local path:
- Branch:
- Deployment:

## Product Summary

## Users / Roles

## What Was Done

## Current Architecture

## Important Files

## Database / Backend Notes

## Environment / Secrets Notes

## Known Issues

## Pending Tasks

## Commands

## Next Recommended Steps
```

## Quality Bar

The handoff should be clear enough that a new LLM can:

- understand what the product does
- know what was changed
- avoid repeating past mistakes
- continue from the current state
- run the right commands
- know what still needs confirmation

## Security Rules

Never include full secret values in the handoff unless the user explicitly requests it in the same turn.

Instead, write:

- which secret type was used
- where it is configured
- whether it should be rotated

## Output Rules

- Output as `.md`.
- Use clean headings.
- Prefer bullets and short paragraphs.
- Include exact paths.
- Mention whether the file was created successfully.
