---
name: project-audit
description: Audit an existing Next.js + Supabase project for security, performance, accessibility, and React best-practice gaps; reports findings by severity (Critical/High/Medium/Low) with a score out of 100 and a prioritised fix list. Use when asked to audit, review, health-check, or "doctor" a codebase, or when asked what needs refactoring.
metadata:
  short-description: Severity-ranked security/performance/React audit of a Next.js + Supabase codebase, scored /100.
---

# /project-audit

You are auditing an existing Next.js + Supabase project for security gaps, performance issues, and React best-practice violations. Work through every section below. Report findings grouped by severity: Critical → High → Medium → Low. At the end, give a score out of 100 and a prioritised fix list.

---

## 1. Security audit — Server actions (CRITICAL)

Find every `"use server"` file:
```bash
grep -rn '"use server"' src/ --include="*.ts" --include="*.tsx" -l
```

For each file, check that every exported `async function` has `await requireUser()` or `await requireAdmin()` as its FIRST statement — before any validation, database call, or business logic.

**Flag as CRITICAL if:**
- Any exported action accesses a database or external service without an auth check
- The auth check happens after other logic (e.g. after parsing FormData)
- The file imports from the database but has no auth import at all

**How to fix:** Add `await requireUser()` as line 1 of every exported action function. If the action requires admin privileges, use `await requireAdmin()` instead.

**Identify the project's own auth wrapper first.** It may be `requireUser` / `requireAdmin` / `requireRole(...)` — grep `src/lib/auth*` to learn the name, then verify it's the first statement. Note: react-doctor's `server-auth-actions` rule only recognizes literal `auth()` / `getSession()`, so it will report nearly every correctly-guarded action as a false-positive "error." Once you've manually confirmed the wrapper is line 1 on each action, treat that react-doctor category as noise — don't let it drag your assessment.

**Helpers vs actions:** a `"use server"` file can only *export* async functions, but an exported helper (e.g. `notifyUsers(supabase, ...)` taking a pre-authed client) is still reachable as an action. Prefer keeping such helpers un-exported, or guard them too.

**Legitimate public exception:** a deliberately unauthenticated action (e.g. a public submission/contact form) is OK *without* an auth check **only if** it (a) validates every input against server-derived scope — look up the cohort/tenant/owner server-side and confirm the submitted id belongs to it, never trusting the client id alone — and (b) writes via a tightly-scoped service-role path, not by loosening anon RLS. Flag any public action that writes based on unvalidated client input.

---

## 2. Security audit — Environment variables

Check for secrets exposed to the client:
```bash
grep -rn "SUPABASE_SERVICE_ROLE\|SECRET\|PRIVATE_KEY\|API_SECRET" src/ --include="*.tsx" --include="*.ts" | grep -v "NEXT_PUBLIC" | grep "NEXT_PUBLIC"
```

Also check `.env.example` exists and documents all required variables without committing real values.

**Flag as CRITICAL if:**
- Any secret key is prefixed with `NEXT_PUBLIC_`
- `.env.local` or real credentials are committed to git

Check:
```bash
git log --all --full-history -- "*.env*" | head -5
grep -r "service_role\|eyJh" .env* 2>/dev/null | head -5
```

---

## 2b. Admin user-management audit (CRITICAL if present)

If the project has an admin-invites-users flow (creating accounts, resetting passwords, changing roles), audit it. Find it:
```bash
grep -rln "auth.admin\|createAdminClient\|inviteUserByEmail\|createUser\|updateUserById" src/ --include="*.ts" --include="*.tsx"
```

For each admin action file, verify:

**Flag as CRITICAL if:**
- Any `auth.admin.*` / service-role call lives outside a `"use server"` file, or the service-role key is reachable from client code (search `grep -rn "SERVICE_ROLE" src/` — any hit in a `"use client"` file or `NEXT_PUBLIC_` is critical).
- An admin action is missing `await requireAdmin()` as its first statement.
- User creation does **not roll back** the auth user when the profile/row insert fails (orphaned auth users with no profile).

**Flag as HIGH if:**
- Passwords are generated with `Math.random()` instead of `crypto.getRandomValues` (predictable credentials).
- There is no "last active admin" guard on demote / deactivate / delete (an admin can lock the whole org out).
- The generated/reset password is logged, stored in plaintext beyond the one-time display, or sent over an insecure channel.

**Flag as MEDIUM if:**
- No minimum password length enforced on invite/reset (8 is a sensible floor).
- The invite message is built but the credentials persist in client state longer than needed (should be shown once, then clearable).

**How to fix:** See `/new-project-setup` Step 4b for the reference implementation (service-role admin client in server actions, crypto password generator, rollback on failure, last-admin guard, copy-once invite message).

---

## 3. Supabase RLS audit (CRITICAL)

Ask the user to run this in Supabase SQL Editor and share the output:

```sql
-- Check which tables have RLS enabled
select schemaname, tablename, rowsecurity
from pg_tables
where schemaname = 'public'
order by tablename;

-- Check which policies exist
select tablename, policyname, cmd, qual
from pg_policies
where schemaname = 'public'
order by tablename, cmd;
```

**Flag as CRITICAL if:**
- Any table has `rowsecurity = false` (RLS not enabled)
- Any table has RLS enabled but no policies (silently blocks ALL access — no error, just empty results)
- Any table has SELECT but no INSERT/UPDATE/DELETE policy when the app writes to it

**The silent failure pattern:** Enabling RLS without write policies does NOT throw an error. The insert/update simply returns success with 0 rows affected, or fails with a vague "permission denied" that maps to a confusing user-facing message.

---

## 4. React 19 — forwardRef

```bash
grep -rn "forwardRef" src/components/ | grep -v ".test." | grep -v "node_modules"
```

**Flag as HIGH if any results.** In React 19, `ref` is a regular prop on function components. `forwardRef` is deprecated and adds unnecessary boilerplate.

**How to fix:**
```tsx
// Before
const Comp = forwardRef<HTMLDivElement, Props>((props, ref) => <div ref={ref} {...props} />);

// After
function Comp({ ref, ...props }: Props & { ref?: React.Ref<HTMLDivElement> }) {
  return <div ref={ref} {...props} />;
}
```

---

## 4b. Accessibility — form labels & custom controls

```bash
# Inputs/textareas with a placeholder but no label/aria-label (common a11y miss)
grep -rn "placeholder=" src/ --include="*.tsx" | grep -v "aria-label" | head -20
# <label> wrapping a custom component instead of a native input
grep -rn "<label" src/ --include="*.tsx" -A2 | grep -iE "SelectMenu|<Button|Toggle|Combobox" | head
```

**Flag as MEDIUM if:**
- A placeholder-only `<input>`/`<textarea>` has no associated `<label htmlFor>` or `aria-label` (screen readers announce no field name). The cheapest systemic fix: make the shared `Input`/`Textarea` components fall back to `aria-label ?? placeholder`.
- A `<label>` wraps a **custom** control (a `SelectMenu`/`Button`/component that renders a `<button>` or `<div>`, not a native `input/select/textarea`). The label associates with nothing → use a `<div>` for the visible text and put `aria-label` on the control.
- An icon-only `<button>` has no `aria-label`.

These map to react-doctor's `control-has-associated-label`, `label-has-associated-control`, and `button-has-type`. They matter — placeholder-only forms are unusable on a screen reader.

---

## 4c. Accessibility — reduced motion & em-dashes in copy

```bash
grep -rn "prefers-reduced-motion" src/app/globals.css || echo "MISSING reduced-motion block"
grep -rn "—" src/ --include="*.tsx" | grep -vE "^\s*//|\* |\"—\"|>—<" | head
```

**Flag as LOW if:**
- No global `@media (prefers-reduced-motion: reduce)` block exists while the app uses `animate-*`/transitions (motion-sensitivity a11y).
- Em-dashes (`—`) appear in **JSX text** (user-facing copy) — replace with `:` / `.` / `;`. (An em-dash used as an empty-value placeholder like `{value || "—"}` is fine.)

---

## 5. Tailwind — size shorthand

```bash
grep -rn "w-\([0-9]*\) h-\1\|h-\([0-9]*\) w-\2" src/ --include="*.tsx" --include="*.ts" | head -20
```

Or more practically, run:
```bash
grep -rEn "w-[0-9]+ h-[0-9]+|h-[0-9]+ w-[0-9]+" src/ --include="*.tsx" | head -20
```

**Flag as MEDIUM** for any matching `w-N h-N` pair with equal values. Replace with `size-N` (Tailwind v3.4+).

---

## 6. Performance — Sequential awaits

```bash
grep -rn "await " src/app/ --include="*.ts" --include="*.tsx" -A1 | grep -B1 "await " | head -30
```

Look for patterns like:
```ts
const a = await fetchA();
const b = await fetchB(); // b doesn't depend on a
```

**Flag as MEDIUM** when two or more awaits in a row don't depend on each other. Fix with `Promise.all([fetchA(), fetchB()])`.

---

## 7. Performance — Intl constructors

```bash
grep -rn "new Intl\." src/ --include="*.ts" --include="*.tsx"
```

**Flag as MEDIUM** for any `new Intl.DateTimeFormat()` or `new Intl.NumberFormat()` inside a function body. These allocate heavily and should be at module scope.

---

## 8. Performance — map+filter chains

```bash
grep -rn "\.map(.*)\.\(filter\|find\)" src/ --include="*.ts" --include="*.tsx" | grep -v ".test." | head -20
```

**Flag as LOW** for `.map().filter(Boolean)` — replace with `.flatMap()`.

---

## 9. Error boundaries

```bash
find src/app -name "error.tsx" | head -20
```

**Flag as HIGH** if any route segment under `(protected)` or similar auth-gated folders has no `error.tsx`. Without it, any unhandled render error becomes a white screen crash with no recovery path.

---

## 9b. `redirect()` / `notFound()` inside try-catch (HIGH)

```bash
grep -rn "redirect(\|notFound(" src/app src/lib --include="*.ts" --include="*.tsx" | head -20
```

For each hit, check whether it sits **inside a `try` block**.

**Flag as HIGH** if `redirect()` or `notFound()` is called inside a `try` whose `catch` rethrows/wraps the error. In Next.js these functions work by *throwing* a special control signal (`NEXT_REDIRECT` / `NEXT_NOT_FOUND`). A surrounding `catch (error) { throw new Error(...) }` swallows that signal and the navigation **silently fails** — the action appears to succeed but never redirects.

**The trap:** this looks correct and even typechecks. It only breaks at runtime, and the symptom (form submits, stays on the page) is easy to misdiagnose.

**How to fix:** move the `redirect()` call **outside** the try block (capture the target id/route in a variable inside the try, redirect after it), or call `unstable_rethrow(error)` first in the catch.

```ts
let createdId = "";
try {
  // ...insert...
  createdId = data.id;
} catch (error) {
  throw new Error(safeErrorMessage(error));
}
redirect(`/records/${createdId}`); // outside the try
```

---

## 10. react-doctor score

Run:
```bash
npx react-doctor@latest
```

Record the score. Anything below 85 needs immediate attention. Anything below 70 is a problem.

Report the score and the top 3 issue categories.

---

## Scoring rubric

| Check | Max points |
|---|---|
| All server actions auth-guarded | 25 |
| No secrets in NEXT_PUBLIC_ vars | 10 |
| RLS enabled + policies on all tables | 20 |
| No forwardRef (React 19) | 10 |
| Error boundaries on protected segments | 10 |
| react-doctor score ≥ 90 | 10 |
| Tailwind size shorthand | 5 |
| No sequential independent awaits | 5 |
| Intl constructors at module scope | 3 |
| .env.example committed, .env.local gitignored | 2 |
| **Total** | **100** |

---

## Output format

After running all checks, report:

```
## Project Audit Results

Score: XX / 100

### 🔴 Critical (fix before any users touch this)
- [list]

### 🟠 High (fix before production)
- [list]

### 🟡 Medium (fix this sprint)
- [list]

### 🟢 Low (nice to have)
- [list]

### Fix order
1. ...
2. ...
```

Then ask: "Want me to fix these now, starting with Critical?"
