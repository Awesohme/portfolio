---
description: Apply the right effort level and model per task to get maximum quality at minimum cost. Use this whenever you need to choose how hard to think about a task, which model to use, or whether to enable fast mode.
---

# /effort-routing

You are helping a developer get maximum value from their AI assistant by routing each task to the right effort level, model, and mode. Apply this framework to every task before starting.

---

## Step 1 — Classify the task type

| Task type | Signal words in the prompt | Effort level |
|---|---|---|
| Lookup / question | "where is", "what is", "which file", "show me", "list", "find" | **Low** |
| Mechanical edit | rename, typo, format, add import, fix spacing | **Low** |
| Standard feature / bug fix | implement, add, fix, refactor, update, create | **Medium** (default) |
| Deep reasoning / tracing | why is, debug, trace, investigate, design the, architect | **High** |
| Security / PR review | audit, review PR, security review | **High** |
| Full codebase / comprehensive | ultra, all files, comprehensive audit, worst case | **Max** |

When in doubt, use **Medium**. Only go higher when reasoning depth genuinely matters.

---

## Step 2 — Apply the file-count rule

- 1 file, obvious change → Low or Medium
- 2–5 files with cross-file logic → Medium minimum
- 5+ files or architectural impact → High or Max

---

## Step 3 — Apply the stakes rule

| Stakes | Guidance |
|---|---|
| Dev/test, throwaway, easily reversible | Prefer cheaper (Low/Medium) |
| Production-facing, or hard to reverse | Prefer higher (High/Max) |
| Security-adjacent, auth, payments | Always High minimum |

---

## Step 4 — Fast mode decision

Enable fast mode when:
- The task is purely mechanical (no reasoning required)
- You need speed more than depth
- The output is boilerplate, formatting, or a simple rename

Do NOT use fast mode when:
- The task involves subtle bugs, edge cases, or cross-file logic
- Correctness matters more than speed

---

## Quick-fire examples

| Prompt | Right choice | Reason |
|---|---|---|
| "Where is the auth middleware?" | Low + fast | Pure lookup |
| "Fix this typo in the README" | Low + fast | Single line, zero risk |
| "Add a loading spinner to the dashboard" | Medium | Standard feature, 2–3 files |
| "Why is the JWT expiry check silently failing?" | High | Deep data-flow trace, subtle bug |
| "Review this PR before merge" | High | Correctness + security at stake |
| "Design the multi-tenant data model" | Max | Architecture, long-term consequences |

---

## Model routing (Claude Code sub-agents)

| Model | Use for |
|---|---|
| Haiku 4.5 | File search, grep, symbol lookup, Explore agents, boilerplate edits, quality checks on small diffs |
| Sonnet 4.6 | Feature planning, multi-file edits, bug tracing, data-flow debugging, orchestration |
| Opus 4.8 | Security reviews, PR reviews, architecture decisions with significant trade-offs |

Rules:
- Explore agents → always Haiku 4.5
- Anything touching >2 files with cross-file logic → Sonnet minimum
- Opus only when explicitly needed — it is ~5x the cost of Sonnet

---

## The one discipline that cuts cost in half

Before every prompt, ask: **"Does this need deep reasoning, or just execution?"**

- Execution → Low + fast
- Reasoning → Medium or higher

Most prompts are execution. Most developers default everything to High. The gap between those two behaviours is where the cost savings live.

---

## Self-improvement (Claude Code only)

If you have access to `~/.claude/effort-log.jsonl`, scan recent entries at session end for:
- `low` effort on prompts containing reasoning words → may be underpowered
- `high`/`max` effort on simple lookup prompts → may be overpowered

Suggest conservative rule changes to `~/.claude/hooks/effort-rules.json`. Never auto-apply — present suggestions for the developer to review.
