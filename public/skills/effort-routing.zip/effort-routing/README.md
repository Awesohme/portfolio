# Effort Routing

A simple way to choose how hard the AI should think, and which model to use, so you get quality without paying for it everywhere.

Works with: Claude Code

## Install

**Claude Code:** copy the `.md` command file into `~/.claude/commands/`, then type `/` plus its file name (without `.md`) in a new session.

**Other AI agents (Codex, Cursor, Aider, Gemini and others):** open the `.md` file and paste it into your agent as instructions, or save it wherever your tool keeps its rules or custom commands. Each file is written in plain steps, so any capable coding agent can follow it.

## Before you start

The field guide describes an optional auto-routing hook. That hook isn't part of this download; the framework works without it.

## Licence

Free to use, change and share. A link back is appreciated but not required.

Made by Olamide Irojah · https://www.olamide-irojah.com.ng/skills
